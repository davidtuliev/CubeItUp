﻿using UnityEngine;

public class Colision : MonoBehaviour {

    public PlayerMovement move;

	void OnCollisionEnter(Collision colInfo)
    {
        if(colInfo.collider.tag == "Obstacle")
        {
            move.enabled = false;
            //pri dopiranje so nekoja prepreka ja stopira igrata i go resetira nivoto
            FindObjectOfType<GameManager>().endGame();
        }
        if(colInfo.collider.tag == "Powerup")
        {
            move.fForce += 2000*Time.deltaTime;
            move.sForce += 25 * Time.deltaTime;
        }
        if (colInfo.collider.tag == "Sidepowerup")
        {
            move.sForce += 75 * Time.deltaTime;
        }
    }

}
