﻿using UnityEngine;

public class Credits : MonoBehaviour {

	public void quit()
    {
        Application.Quit();
    }

}
