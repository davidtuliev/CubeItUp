﻿using UnityEngine;

public class LevelEnd : MonoBehaviour {

    public GameManager gameManager;
    //pri dopir na igracot so zavrsniot objekt na nivoto se povikuva ovaa skripta
    //go povikuva completelevel od gamemanager i ja stava animacijata za zavrsen level na ekran

	void OnTriggerEnter()
    {
        gameManager.CompleteLevel();
    }

}
