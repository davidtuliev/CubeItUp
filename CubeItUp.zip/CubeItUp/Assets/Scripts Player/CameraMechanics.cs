﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMechanics : MonoBehaviour {

    public Transform player;
    //vector gi cuva x,y,z koardinatite;
    public Vector3 offset;
	void Update () {
        transform.position = player.position + offset;
	}
}
