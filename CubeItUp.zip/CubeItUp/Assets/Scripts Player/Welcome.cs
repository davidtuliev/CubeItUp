﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class Welcome : MonoBehaviour {

	public void startGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
}
