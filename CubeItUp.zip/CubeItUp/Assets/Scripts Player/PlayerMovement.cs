﻿using UnityEngine;

public class PlayerMovement : MonoBehaviour {

    public Rigidbody rb;
    public float fForce = 2000f;
    public float sForce = 700f;
	void Start () {

	}
	// se koristi FixedUpdate bidejki raboteme so physics
	void FixedUpdate () {
        // se mnozi so time.deltatime za da bide ednakva brzinata na kakov i da e pc
        // shto pogolemo fps tolku pomalo deltatime
        rb.AddForce(0, 0, fForce* Time.deltaTime);//dava sila na z oskata

        if(Input.GetKey("d"))
        {
            rb.AddForce(sForce * Time.deltaTime,0,0, ForceMode.VelocityChange);
        }
        if (Input.GetKey("a"))
        {
            rb.AddForce(-sForce * Time.deltaTime,0, 0, ForceMode.VelocityChange);
        }
        if (rb.position.y < -1f)
        {
            FindObjectOfType<GameManager>().endGame();
        }
    }
}
