﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class levelcomplete : MonoBehaviour {
    //so ovaa funkcija go povikuvame slednoto nivo po zavrsuvanje na prethodnoto
    //loadira scena vr osnova na buildIndax-ot koj e postaven vo build settings na unity
	public void loadNextLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex+1);
    }
}
