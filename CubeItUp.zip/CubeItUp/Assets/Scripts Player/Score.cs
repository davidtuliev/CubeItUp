﻿using UnityEngine;
//se koristi using UnityEngine.UI; za rabota so ui elementi
using UnityEngine.UI;

public class Score : MonoBehaviour {

    public Transform player;
    public Text score;

    // ja zemame pozicijata na igracot na z oskata i ja prikazuvame 
    // na ekran preku ui elementot score 
	void Update () {
        //"0" se koristi za prikazuvanje na tekstot kako integer mesto float
        score.text = player.position.z.ToString("0");
	}
}
